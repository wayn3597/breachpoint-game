import React, { useState } from "react";
import { motion } from "framer-motion";

const challenges = [
  {
    id: 1,
    type: "phishing",
    prompt:
      "You received this email: 'Urgent! Update your payroll info to avoid account suspension.' What do you do?",
    answer: "report phishing"
  },
  {
    id: 2,
    type: "logs",
    prompt:
      "Log analysis shows user 'jsmith' logged in from 2 locations 2,000 miles apart within 1 hour. What’s your first action?",
    answer: "disable account"
  },
  {
    id: 3,
    type: "incident",
    prompt:
      "Ransomware detected on HR laptop. What do you do first?",
    answer: "isolate endpoint"
  }
];

export default function BreachPointGame() {
  const [step, setStep] = useState(0);
  const [input, setInput] = useState("");
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState("");

  const handleSubmit = () => {
    const current = challenges[step];
    if (input.toLowerCase().includes(current.answer)) {
      setScore(score + 100);
      setFeedback("✅ Correct! +100 points");
    } else {
      setScore(score - 50);
      setFeedback("❌ Incorrect. -50 points");
    }
    setTimeout(() => {
      setFeedback("");
      setInput("");
      setStep(step + 1);
    }, 1500);
  };

  if (step >= challenges.length) {
    return (
      <div className="p-10 text-center">
        <h1 className="text-3xl font-bold mb-4">🏁 Game Over</h1>
        <p className="text-xl">Your Score: {score}</p>
      </div>
    );
  }

  return (
    <div className="p-10 max-w-2xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-6 p-6 bg-white rounded-2xl shadow-xl border border-gray-200">
          <h2 className="text-xl font-semibold mb-4">Challenge {step + 1}</h2>
          <p className="mb-6">{challenges[step].prompt}</p>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Your response..."
            className="mb-4 p-2 w-full border border-gray-300 rounded-md shadow-sm"
          />
          <button
            onClick={handleSubmit}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-md"
          >
            Submit
          </button>
          {feedback && <p className="mt-4 text-lg font-medium">{feedback}</p>}
        </div>
        <div className="text-right text-sm text-gray-500">
          Score: {score}
        </div>
      </motion.div>
    </div>
  );
}